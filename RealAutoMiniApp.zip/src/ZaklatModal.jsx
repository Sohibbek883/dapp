
import React from "react";

export default function ZaklatModal({ onClose }) {
  return (
    <div style={{
      position: "fixed", top: 0, left: 0, width: "100%", height: "100%",
      backgroundColor: "rgba(0,0,0,0.5)", display: "flex",
      alignItems: "center", justifyContent: "center"
    }}>
      <div style={{
        background: "#fff", padding: "20px", borderRadius: "10px",
        textAlign: "center", width: "90%", maxWidth: "300px"
      }}>
        <h3>💳 To‘lov usuli tanlang:</h3>
        <a href="https://payme.uz" target="_blank" rel="noopener noreferrer">Payme</a><br />
        <a href="https://click.uz" target="_blank" rel="noopener noreferrer">Click</a><br />
        <a href="https://t.me/yourcryptoaddress" target="_blank" rel="noopener noreferrer">Crypto</a><br /><br />
        <button onClick={onClose}>Yopish</button>
      </div>
    </div>
  );
}


import React, { useState } from "react";
import { carData } from "./data";
import { ads } from "./mockAds";
import ZaklatModal from "./ZaklatModal";

export default function App() {
  const [selectedBrand, setSelectedBrand] = useState("");
  const [selectedModel, setSelectedModel] = useState("");
  const [showModal, setShowModal] = useState(false);

  const filteredAds = ads.filter(
    ad => ad.brand === selectedBrand && ad.model === selectedModel
  );

  return (
    <div style={{ padding: "20px", backgroundColor: "#ffffff", minHeight: "100vh" }}>
      <h2 style={{ color: "#003399" }}>🚘 RealAuto Mashina Filtri</h2>

      <label>Marka tanlang:</label>
      <select value={selectedBrand} onChange={(e) => {
        setSelectedBrand(e.target.value);
        setSelectedModel("");
      }}>
        <option value="">-- Tanlang --</option>
        {Object.keys(carData).map(brand => (
          <option key={brand} value={brand}>{brand}</option>
        ))}
      </select>

      {selectedBrand && (
        <>
          <br /><label>Model tanlang:</label>
          <select value={selectedModel} onChange={(e) => setSelectedModel(e.target.value)}>
            <option value="">-- Model tanlang --</option>
            {carData[selectedBrand].map(model => (
              <option key={model} value={model}>{model}</option>
            ))}
          </select>
        </>
      )}

      <div style={{ marginTop: "20px" }}>
        {filteredAds.length > 0 ? filteredAds.map((ad, index) => (
          <div key={index} style={{
            border: "1px solid #ccc",
            borderRadius: "10px",
            padding: "15px",
            marginBottom: "10px",
            backgroundColor: ad.status === "sold" ? "#f8d7da" : "#e9f7ef"
          }}>
            <strong>{ad.brand} {ad.model}</strong>
            <p>{ad.info}</p>
            {ad.status === "sold" ? (
              <p style={{ color: "#c0392b", fontWeight: "bold" }}>SOTILDI ✅</p>
            ) : (
              <>
                <button onClick={() => setShowModal(true)} style={{ backgroundColor: "#003399", color: "#fff", padding: "5px 10px", borderRadius: "5px" }}>
                  Zaklat
                </button>
                <a href="tel:+998333152222">
                  <button style={{ marginTop: "10px", background: "#00aaff", color: "#fff", padding: "5px 10px", borderRadius: "5px" }}>
                    📞 Bog‘lanish
                  </button>
                </a>
              </>
            )}
          </div>
        )) : selectedModel && (
          <p style={{ marginTop: "10px", color: "gray" }}>Hech qanday e'lon topilmadi.</p>
        )}
      </div>

      {showModal && <ZaklatModal onClose={() => setShowModal(false)} />}
    </div>
  );
}

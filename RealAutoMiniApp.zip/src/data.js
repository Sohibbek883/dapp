
export const carData = {
  "Chevrolet": ["Gentra", "Cobalt", "Malibu", "Lacetti"],
  "KIA": ["K5", "K8", "K9"],
  "Hyundai": ["Sonata", "Elantra", "Tucson"],
  "BYD": ["Song Plus", "Han", "Qin"]
};

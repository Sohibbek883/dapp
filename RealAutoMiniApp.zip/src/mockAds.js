
export const ads = [
  { brand: "Chevrolet", model: "Gentra", info: "2023 yil, 85,000km, 💰13,100$", status: "available" },
  { brand: "Chevrolet", model: "Cobalt", info: "2022 yil, 75,000km, 💰11,800$", status: "sold" },
  { brand: "KIA", model: "K5", info: "2024 yil, 20,000km, 💰26,000$", status: "available" },
  { brand: "Hyundai", model: "Sonata", info: "2023 yil, 40,000km, 💰22,000$", status: "available" },
  { brand: "BYD", model: "Han", info: "2023 yil, 15,000km, 💰28,000$", status: "sold" }
];
